package com.example.contact

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText

class LoginActivity : AppCompatActivity() {

    private lateinit var emailEditText: TextInputEditText
    private lateinit var passwordEditText: TextInputEditText
    lateinit var signup : TextView
    private lateinit var sharedPreferences: SharedPreferences


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        emailEditText = findViewById(R.id.edt3)
        passwordEditText = findViewById(R.id.edt4)
        signup = findViewById(R.id.regesterscreen)
        sharedPreferences = getSharedPreferences("loginPrefs", Context.MODE_PRIVATE)


        signup.setOnClickListener {

            startActivity(Intent(applicationContext,RegistrationActivity::class.java))
        }

        val loginButton = findViewById<Button>(R.id.btnLogin)
        loginButton.setOnClickListener {
            loginUser()
        }
        checkLoggedInUser()
    }
    private fun loginUser() {
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()

        if (validateInputs(email, password)) {
            val dbHelper = DBHelper(this)
            val user = dbHelper.getUserByEmail(email)

            if (user != null && user.password == password) {
                // User found and password matches, login successful
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()

                saveLoginStatus(email)

                startActivity(Intent(applicationContext, MainActivity::class.java))
            } else {
                // User not found or password doesn't match
                Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun checkLoggedInUser() {
        val email = sharedPreferences.getString("email", null)
        if (!email.isNullOrEmpty()) {
            startActivity(Intent(applicationContext, MainActivity::class.java))
            finish()
        }
    }
    private fun saveLoginStatus(email: String) {
        val editor = sharedPreferences.edit()
        editor.putString("email", email)
        editor.apply()
    }


    private fun validateInputs(email: String, password: String): Boolean {
        if (email.isEmpty()) {
            emailEditText.error = "Email is required"
            emailEditText.requestFocus()
            return false
        }

        if (password.isEmpty()) {
            passwordEditText.error = "Password is required"
            passwordEditText.requestFocus()
            return false
        }

        return true
    }

    override fun onBackPressed() {
        super.onBackPressed()

        finishAffinity()
    }
}