package com.example.contact

import android.Manifest.permission.CALL_PHONE
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.RecyclerView


class ContactAdapter(private val context: Context, private val contactList: List<Contacts>) :
    RecyclerView.Adapter<ContactAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val profileImage: ImageView = itemView.findViewById(R.id.profile_image)
        val textViewName: TextView = itemView.findViewById(R.id.textViewName)
        val textViewNumber: TextView = itemView.findViewById(R.id.textViewNumber)
        val imageViewCall: ImageView = itemView.findViewById(R.id.imageViewCall)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.contactdesign, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val contact = contactList[position]

        // Bind data to views
        holder.textViewName.text = contact.name
        holder.textViewNumber.text = contact.phoneNumber
        // Set onClickListener for call icon
        holder.imageViewCall.setOnClickListener {
            val phoneNumber = contact.phoneNumber
            dialPhoneNumber(phoneNumber.toString())
        }
        val characterBitmap = generateCharacterBitmap(contact.name[0])
        holder.profileImage.setImageBitmap(characterBitmap)

    }
    private fun generateCharacterBitmap(character: Char): Bitmap {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = 40f
        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        val bitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.GRAY)
        canvas.drawText(character.toString(), 50f, 50f - (paint.descent() + paint.ascent()) / 2, paint)
        return bitmap
    }
    private fun dialPhoneNumber(phoneNumber: String) {
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber"))
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        if (ActivityCompat.checkSelfPermission(context , CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(context as Activity, arrayOf(CALL_PHONE), PERMISSION_REQUEST_CALL_PHONE)
        } else {
            context.startActivity(intent)
        }
    }


    override fun getItemCount(): Int {
        return contactList.size
    }
    companion object {
        private const val PERMISSION_REQUEST_CALL_PHONE = 1
    }
}
