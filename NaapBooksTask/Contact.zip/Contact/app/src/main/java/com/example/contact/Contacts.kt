package com.example.contact

data class Contacts(val name: String, val phoneNumber: String?)
