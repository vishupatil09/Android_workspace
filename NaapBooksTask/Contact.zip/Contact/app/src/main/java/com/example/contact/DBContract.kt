package com.example.contact

import android.provider.BaseColumns

object DBContract {
    // Define the table schema for the contacts table
    object ContactEntry : BaseColumns {
        const val TABLE_NAME = "contacts"
        const val COLUMN_NAME = "name"
        const val COLUMN_PHONE_NUMBER = "phone_number"
    }
}
