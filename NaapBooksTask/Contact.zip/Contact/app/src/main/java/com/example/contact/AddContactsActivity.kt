package com.example.contact

import android.content.ContentValues
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class AddContactsActivity : AppCompatActivity() {
    lateinit var editTextName: EditText
    lateinit var editTextPhoneNumber: EditText
    lateinit var buttonSaveContact: Button
    lateinit var dbHelper: DBHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_contacts)
        editTextName = findViewById(R.id.editTextName)
        editTextPhoneNumber = findViewById(R.id.editTextPhoneNumber)
        buttonSaveContact = findViewById(R.id.buttonSaveContact)
        dbHelper = DBHelper(this)

        buttonSaveContact.setOnClickListener(View.OnClickListener { saveContact() })
    }

    private fun saveContact() {
        val name = editTextName!!.text.toString().trim { it <= ' ' }
        val phoneNumber = editTextPhoneNumber!!.text.toString().trim { it <= ' ' }
        if (name.isEmpty() || phoneNumber.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            return
        }
        val database = dbHelper!!.writableDatabase
        val values = ContentValues()
        values.put(DBContract.ContactEntry.COLUMN_NAME, name)
        values.put(DBContract.ContactEntry.COLUMN_PHONE_NUMBER, phoneNumber)
        val newRowId = database.insert(DBContract.ContactEntry.TABLE_NAME, null, values)
        if (newRowId == -1L) {
            Toast.makeText(this, "Error saving contact", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Contact saved successfully", Toast.LENGTH_SHORT).show()
            finish() // Close the activity after saving
        }
    }
}
