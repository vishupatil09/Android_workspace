package com.example.contact

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "UserDB"
        private const val DATABASE_VERSION = 1

        private const val TABLE_NAME = "users"
        private const val COLUMN_ID = "id"
        private const val COLUMN_FIRST_NAME = "first_name"
        private const val COLUMN_LAST_NAME = "last_name"
        private const val COLUMN_EMAIL = "email"
        private const val COLUMN_MOBILE = "mobile"
        private const val COLUMN_PASSWORD = "password"
        private const val COLUMN_IMAGE_PATH = "image_path" // New column for image path

        private const val CREATE_TABLE =
            "CREATE TABLE $TABLE_NAME($COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "$COLUMN_FIRST_NAME TEXT, " +
                    "$COLUMN_LAST_NAME TEXT, " +
                    "$COLUMN_EMAIL TEXT, " +
                    "$COLUMN_MOBILE TEXT, " +
                    "$COLUMN_PASSWORD TEXT, " +
                    "$COLUMN_IMAGE_PATH TEXT)" // Include image path column in the table
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun addUser(user: User): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_FIRST_NAME, user.firstName)
        values.put(COLUMN_LAST_NAME, user.lastName)
        values.put(COLUMN_EMAIL, user.email)
        values.put(COLUMN_MOBILE, user.mobile)
        values.put(COLUMN_PASSWORD, user.password)
        values.put(COLUMN_IMAGE_PATH, user.imagePath) // Insert image path
        val id = db.insert(TABLE_NAME, null, values)
        db.close()
        return id
    }

    @SuppressLint("Range")
    fun getUserByEmail(email: String): User? {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_NAME,
            null,
            "$COLUMN_EMAIL = ?",
            arrayOf(email),
            null,
            null,
            null
        )

        var user: User? = null

        if (cursor.moveToFirst()) {
            val firstName = cursor.getString(cursor.getColumnIndex(COLUMN_FIRST_NAME))
            val lastName = cursor.getString(cursor.getColumnIndex(COLUMN_LAST_NAME))
            val userEmail = cursor.getString(cursor.getColumnIndex(COLUMN_EMAIL))
            val mobile = cursor.getString(cursor.getColumnIndex(COLUMN_MOBILE))
            val password = cursor.getString(cursor.getColumnIndex(COLUMN_PASSWORD))
            val imagePath = cursor.getString(cursor.getColumnIndex(COLUMN_IMAGE_PATH))
            user = User( firstName, lastName, userEmail, mobile, password, imagePath)
        }

        cursor.close()
        return user
    }

}