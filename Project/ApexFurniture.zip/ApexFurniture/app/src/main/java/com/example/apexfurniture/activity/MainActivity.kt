package com.example.apexfurniture.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.apexfurniture.ApiInterface.ApiInterface
import com.example.apexfurniture.Apiclient.ApiClient
import com.example.apexfurniture.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity()
{
    private lateinit var binding: ActivityMainBinding
    private lateinit var apiinterface: ApiInterface

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)


        binding.btnRegister.setOnClickListener {

            val name = binding.edtFullName.text.toString()
            val email = binding.edtEmail.text.toString()
            val phone = binding.edt3.text.toString()
            val password = binding.edtPassword.text.toString()
            val confirmPassword = binding.edtConfirmPassword.text.toString()

            if (password != confirmPassword) {
                // Passwords don't match
                binding.edtConfirmPassword.error = "Passwords do not match"
            } else if (password.isEmpty()) {
                // Password is empty
                binding.edtPassword.error = "Please Enter a Password"
            } else {
                // Passwords match and password is not empty
                if (name.isEmpty()) {
                    binding.edtFullName.error = "Please Enter Proper First Name"
                }  else if (email.isEmpty()) {
                    binding.edtEmail.error = "Please Enter Proper Email"
                } else if (phone.length != 10) {
                    binding.edt3.error = "Please Enter Proper Phone Number"
                } else {
                    // Proceed with registration
                    apiinterface = ApiClient.getapiclient()!!.create(ApiInterface::class.java)

                    val registerCall: Call<Void> =
                        apiinterface.registerdetail(name, email, phone, password)
                    registerCall.enqueue(object : Callback<Void> {
                        override fun onResponse(call: Call<Void>, response: Response<Void>) {
                            if (response.isSuccessful) {
                                startActivity(Intent(applicationContext, LoginActivity::class.java))
                            } else {
                                Toast.makeText(applicationContext, "Registration failed", Toast.LENGTH_LONG).show()
                            }
                        }

                        override fun onFailure(call: Call<Void>, t: Throwable) {
                            Toast.makeText(applicationContext, "No Internet", Toast.LENGTH_LONG).show()
                        }
                    })
                }
            }
        }
        binding.textAlreadyHaveAccount.setOnClickListener {
            startActivity(Intent(applicationContext, LoginActivity::class.java))


        }

    }
}