package com.example.apexfurniture.model

class AddressModel {

    val id = 0
    val home = ""
    val area = ""
    val city = ""
    val state = ""
    val pincode = ""
}