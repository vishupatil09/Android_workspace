package com.example.apexfurniture.model

class WishlistModel {
    val id = 0
    val img = ""
    val name = ""
    val price = ""
    val description = ""
}