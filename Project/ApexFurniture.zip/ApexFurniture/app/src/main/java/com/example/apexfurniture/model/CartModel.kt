package com.example.apexfurniture.model

class CartModel
{

    val id = 0
    val img = ""
    val name = ""
    val price = ""
    val description = ""
}