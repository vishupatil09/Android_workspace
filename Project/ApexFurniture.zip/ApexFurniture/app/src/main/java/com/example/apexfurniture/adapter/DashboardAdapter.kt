package com.example.apexfurniture.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.view.menu.MenuView.ItemView
import androidx.recyclerview.widget.RecyclerView
import com.example.apexfurniture.R
import com.example.apexfurniture.activity.CategoryViewActivity
import com.example.apexfurniture.model.DashboardModel
import com.squareup.picasso.Picasso

class DashboardAdapter (var context: Context, var list: MutableList<DashboardModel>): RecyclerView.Adapter<MyView>()


{
    private val VIEW_TYPE_ITEM = 0
    private val VIEW_TYPE_LOADING = 1

    inner class LoadingViewHolder(itemview: View) : MyView(itemview) {
        val progressBar: ProgressBar = itemView.findViewById(R.id.progressBar)
    }


    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItemCount(): Int {
        return list.size
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyView {
        return when (viewType) {
            VIEW_TYPE_ITEM -> {
                val view = LayoutInflater.from(parent.context)
                    .inflate(R.layout.design_dashboard, parent, false)
                MyView(view)
            }
            VIEW_TYPE_LOADING -> {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.progressbar, parent, false)
                LoadingViewHolder(view)
            }
            else -> throw IllegalArgumentException("Invalid view type")
        }
    }


    override fun getItemViewType(position: Int): Int {
        return if (list[position] == null) VIEW_TYPE_LOADING else VIEW_TYPE_ITEM
    }



    override fun onBindViewHolder(holder: MyView , position: Int)
    {


        if (holder is MyView) {
            holder.textView.setText(list.get(position).p_type)
            Picasso.get().load(list.get(position).img).into(holder.imageview2)
        } else if (holder is LoadingViewHolder) {
            // Handle progress bar as needed
            val isLoading = false
                if (isLoading) {
                    holder.progressBar.visibility = View.VISIBLE
                } else {
                    holder.progressBar.visibility = View.GONE
                }
        }


        holder.itemView.setOnClickListener {

            var i = Intent(context, CategoryViewActivity::class.java)
            i.putExtra("pos",position)
            i.putExtra("catogories",list[position].p_type)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)

        }





    }

    fun fileteredlist(filtedlist: ArrayList<DashboardModel>) {


        list = filtedlist

        notifyDataSetChanged()
    }


}

open class MyView(Itemview: View):RecyclerView.ViewHolder(Itemview)
{
    var textView: TextView = Itemview.findViewById(R.id.dashboard_txt)
    var imageview2: ImageView = Itemview.findViewById(R.id.dashboard_img)
   // var  ProgressBar : ProgressBar = Itemview.findViewById(R.id.progressBar)




}